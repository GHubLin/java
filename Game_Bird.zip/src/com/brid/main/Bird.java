package com.brid.main;

import com.brid.util.GameUtil;

import java.awt.*;
import java.awt.image.BufferedImage;
//把导入的包定义成静态的才可以访问数组类型
import static com.brid.util.Constant.ANIMAL_IMA;

public class Bird {
    int die[]={1};
    //小鸟矩形对象
    private final Rectangle rect;
    //小鸟加速度
    private int acceleration;
    //小鸟生命值
    public boolean life=true;
    //存放动态动物图片
    private final BufferedImage[] images;
    //图片数量
    public static final int BIRD_IMG_COUNT=4;
    //动物的状态
    private int state;  //调用动画
    private int aa;
    public static final int STATE_NORMAR=0;
    public static final int STATE_UP=1;
    public static final int STATE_DOWN=2;
    //设置动物位置
    public int x=200;
    public int y=200;

    //动物移动
    private boolean up=false;
    private final boolean down=false;
    private boolean left=false;
    private final int speed=4;
    //初始化
    public Bird(){
        images=new BufferedImage[BIRD_IMG_COUNT];
        for (int i = 0; i < BIRD_IMG_COUNT; i++) {
            images[i] =GameUtil.loadBufferedImage(ANIMAL_IMA[i]);
        }
        int w=images[1].getWidth();
        int h=images[1].getHeight();
        rect=new Rectangle(w,h);
    }
    //绘制动物
    public void draw(Graphics g){
        flyLogic();
        //传入图片，以及绘制的位置====默认索引image[0]
        g.drawImage(images[state],x,y ,null);
        //绘制小鸟的矩形---小鸟的水平位置是不变的，但竖直的变化的
        //g.drawRect(x,y, (int) rect.getWidth(),rect.height);
        rect.x=this.x;
        rect.y=this.y;
        //矩形的高度和宽度在构造器已定义
    }
    //控制动物移动方向，是动物能上下移动-物理。
    public void flyLogic(){
        if (up){
            acceleration--;
            y+=acceleration;
            if (acceleration<-15){
                acceleration=-15;
            }
            //设置动物移动边界
            if (y<20){
                y=20;
                acceleration=0;
            }
        }
        if (!up) {
            acceleration++;
            y+=acceleration;
            die[0]=y;
            if (acceleration>10){
                acceleration=10;
            }
            y += speed;
            die[0] = y;
            //System.out.println("ooo"+die[0]);
            //设置动物移动边界
          /*  if (y > 800-10) {
                y = 800-10;
                acceleration=0;
            }*/
        }

        if (left){
            acceleration++;
            x-=acceleration;
            System.out.println(x);
            if (acceleration>5){
                acceleration=5;
            }
            if (x<5){
                x=5;
                acceleration=0;
            }

        }

    }
    public int getdie(){
        return die[0];
    }
    //改变动物状态-图片
    public void fly(int fly){
        switch (fly){
            case 1:
                //图片的方向,向上飞
                state=1;
                up=true;
                break;
            case 5:
                //向下飞
                state=2;
                up=false;
                break;
            case 10:
                state=3;
                left=true;
                break;
            case 15:
                state=3;
                left=false;
                break;
            case 20:
                state=4;

                break;
        }
    }
    public Rectangle getRect() {
        return rect;
    }
    public void restartDraw(){
        life=true;//!!!!!!!!!!!!!!!!!!!
        x=200;
        y=200;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
