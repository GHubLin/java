package com.brid.app;

import com.brid.main.GameFrame;

public class GameApp {
   /* public void Start(){
        WindowFrame frame = new WindowFrame();
        Thread t = new Thread(frame);//t代表线程
        //启动线程
        t.start();
    }*/


    public static void main(String[] args) throws Exception {
        new GameFrame();
        //Music.main(args);
    }

}
