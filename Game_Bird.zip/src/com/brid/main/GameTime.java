package com.brid.main;

/**
 * 游戏计时器
 */
public class GameTime {
    private GameFrontGround gameFrontGround;
    //开始
    private long beginTime;
    //结束
    private long endTime;
    //时间差
    private long differ;
    public GameTime(){
        gameFrontGround=new GameFrontGround();
        differ=555;
    }
    public void begin(){
        beginTime=System.currentTimeMillis();
    }
    public long differ(){
        endTime=System.currentTimeMillis();
        return  differ=((endTime-beginTime)/1000);
    }


}
