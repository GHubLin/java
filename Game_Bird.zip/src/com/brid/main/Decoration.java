package com.brid.main;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Decoration {
    private BufferedImage img;
    private int speed;
    private int x,y;
    public Decoration(){};
    public Decoration(BufferedImage img,int speed,int x,int y){
        this.img=img;
        this.speed=speed+1;
        this.x=x;
        this.y=y;
    }
    public void draw(Graphics g){
        g.drawImage(img,x,y,null);
        x-=speed;

    }
    /**
     * 用于判断是否飞出屏幕外
     */
    public boolean isOutFrame(){
        if (x<10){
            return true;
        }
        return false;
    }

    public BufferedImage getImg() {
        return img;
    }

    public void setImg(BufferedImage img) {
        this.img = img;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
