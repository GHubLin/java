package com.brid.app;


import com.brid.main.GameBarrierLayer;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Huey
 * @date 2020-11-16
 * 登录界面：用户名输入框  密码输入框  登录取消按钮 功能
 *
 */
public class LoginFrame extends JFrame{
    GameBarrierLayer gameBarrierLayer;
    //用户名变量（文本）
    JLabel userLabel;
    //随机数变量
    JLabel randomLabel;
    //用户名输入框（文本输入框）
    JTextField userField;
    //随机数范围输入框（文本输入框）
    JTextField randomField;
    /*//密码变量（文本）
    JLabel userLabel2;
    //密码输入框（文本输入框）
    JPasswordField userField2;*/
    //登录按钮、取消按钮（按钮）
    JButton Login,Cancel;
    public static String sr;
    public static String ra;


    public LoginFrame() {//直接 alt / （无参构造）

    }


/*    public String user(){
        String s="";
        for (int i = 0; i < list.size(); i++) {
                s=list.get(i);
        }
        return s;
    }*/
    public void Start(){
        gameBarrierLayer=new GameBarrierLayer();
        userLabel = new JLabel("请设置名称:");
        randomLabel=new JLabel("请选择游戏困难程度（0～8888）:");
        //设置字体
        userLabel.setFont(new Font("微软雅黑",Font.BOLD,20));
        randomLabel.setFont(new Font("微软雅黑",Font.BOLD,20));
       /* userLabel2 = new JLabel("密  码");
        userLabel2.setFont(new Font("微软雅黑",Font.BOLD,18));*/

        //布局方式：绝对布局
        userLabel.setBounds(20+200+100+50, 220, 100+100, 30);//x位置，y位置，所占显示空间的大小
        this.add(userLabel);//将用户名这三个字添加到登录界面上，以下同理
        /*userLabel2.setBounds(20, 280, 100, 30);
        this.add(userLabel2);*/
        randomLabel.setBounds(20+150, 220+50, 100+150+100, 30);//x位置，y位置，所占显示空间的大小
        this.add(randomLabel);


        //用户名输入框
        userField = new JTextField();
        userField.setBounds(80+200+200, 220, 100+100, 30);
        //设置输入框凹陷效果
        userField.setBorder(BorderFactory.createLoweredBevelBorder());
        //设置输入框背景透明
        userField.setOpaque(false);
        this.add(userField);

        //随机设置
        randomField=new JTextField();
        randomField.setBounds(80+200+200, 220+50, 100+100, 30);
        randomField.setBorder(BorderFactory.createLoweredBevelBorder());
        randomField.setOpaque(false);
        this.add(randomField);
        /*userField2 = new JPasswordField();
        userField2.setBounds(80, 280, 100, 30);
        userField2.setBorder(BorderFactory.createLoweredBevelBorder());
        userField2.setOpaque(false);
        this.add(userField2);*/
//登录按钮
        Login = new JButton("登录");
        Login.setBounds(45+200+200,350,60,36);
        //Login.setBackground(new Color(44,22,44));//背景色
        //Login.setForeground(Color.BLUE);//前景色
        //绑定登录按钮的事件监听
        Login.addActionListener(new ActionListener() {//ActionListener alt /

            @Override
            public void actionPerformed(ActionEvent e) {
                //System.out.println("点击登录按钮");
                //获取用户名输入框的内容
                String userName = userField.getText();
                sr=userName;
                System.out.println(userName);
                ra= randomField.getText();
                System.out.println(ra);
//                gameBarrierLayer.setSr(userName);
                /* String passWord = userField2.getText();//横杠原因：方法太老了，不推荐用*/
                if(userName.equals(userName) /*&& "233".equals(passWord)*/){
                    //登录成功
                    JOptionPane.showMessageDialog(null, "欢迎"+userName+"来到会飞的小猫");
                    //关闭当前界面
                    dispose();
                    //跳转到下一界面
                    new MainFrame();

                }else if("".equals(userName) /*|| "".equals(passWord)*/){
                    //不能为空
                    JOptionPane.showMessageDialog(null, "用户名 不能为空，请重新输入！");
                }else{
                    JOptionPane.showMessageDialog(null, "用户名  输入错误，请重新输入！");
                }

            }
        });

        this.add(Login);

//取消按钮
        Cancel = new JButton("取消");
        Cancel.setBounds(135+200+200,350,60,36);
        this.add(Cancel);
        Cancel.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                dispose();
            }
        });



        //创建背景面板，并添加到窗体上去
        LoginPanel panel = new LoginPanel();
        this.add(panel);

        //设置登录界面的基本属性
        this.setSize(1200,730);
        this.setLocationRelativeTo(null);//位置居中
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setUndecorated(true);

        //设置窗体的Logo图标
        //this.setIconImage(new ImageIcon("Image/115.png").getImage());//存储图片
        this.setVisible(true);
    }
    //测试用的main方法       main + Alt /
    public static void main(String[] args) throws Exception {
        LoginFrame loginFrame=new LoginFrame();
        loginFrame.Start();
        Music.Sound();
    }
    class LoginPanel extends JPanel{//画板
        //背景图片变量
        Image background;//------ctr shift + o 导包
        public LoginPanel() {//-----alt / 回车 构造方法		在{后双击,显示作用域
            //读取图片文件，赋值给background变量
            try {//-----虽然不大可能，但也做好吃饭噎死的准备
                background = ImageIO.read(new File("img/land1111.jpg"));//----read参数为File类型
            } catch (IOException e) {//-------捕获异常信息
                // 打印异常日志信息
                e.printStackTrace();
            }
        }
        //绘制方法
        @Override
        public void paint(Graphics g) {
            super.paint(g);
            //绘制背景图片
            g.drawImage(background, 0, 0,1200,730, null);//900,530为宽高
        }
    }

}
//throws ......抛异常，将下面的异常向上抛,交给上级：不建议

