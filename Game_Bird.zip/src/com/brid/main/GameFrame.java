package com.brid.main;

import com.brid.app.LoginFrame;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

import static com.brid.util.Constant.*;


public class GameFrame extends Frame {
    //图片类声明
    private GameBackGround gameBackGround;
    //动物声明
    private Bird bird;
    //存放图片的图片--图片集（为了可以一次性调用图片来解决图片逐步绘制而闪烁的问题）
    private BufferedImage buffimg=new BufferedImage(FRAM_WIDTH,FRAM_HEIGHT,BufferedImage.TYPE_4BYTE_ABGR);
    //前景类声明
    private GameFrontGround gameFrontGround;
    //障碍物层类声明
    private GameBarrierLayer gameBarrierLayer;
    private GameTime gameTime;
    private Cloud cloud;
    //初始化参数
    public GameFrame()  {
        gameTime=new GameTime();
        setVisible(true);
        setSize(FRAM_WIDTH,FRAM_HEIGHT);
        setTitle(FRAM_TITLE);
        setLocation(FRAM_X,FRAM_Y);
        //窗口大小不可改变
        setResizable(false);
        //窗口关闭事件
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);//结束程序
            }
        });
        //调用实例化构造器
        initGamg();
        //线程启动
        new run().start();
        //添加按键监听
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                add(e);
            }

            @Override
            public void keyReleased(KeyEvent e) {
                minu(e);
            }
        });
    }
    //对游戏中的对象实例化
    public void initGamg(){
        gameBackGround=new GameBackGround();
        bird =new Bird();
        //cloud=new Cloud();
        gameFrontGround=new GameFrontGround();
        gameBarrierLayer=new GameBarrierLayer();
    }

    //调用线程
    class run extends Thread{
        @Override
        public void run() {
            //不断调用绘制下面的方法
            while (true) {
                repaint();  //绘制update方法
                //每30秒调用一次
                try {
                    Thread.sleep(30);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    //所有需要绘制的内容在此方法进行调用绘制
    @Override
    public void update(Graphics g) {
       // System.out.println("777"+gameBarrierLayer.differ);
            if (bird.life){
                //得到图片的画笔
                Graphics graphics=buffimg.getGraphics();
                gameBackGround.draw(graphics);
                bird.draw(graphics);
                //cloud.draw(graphics);
                gameFrontGround.draw(graphics,bird);
                gameBarrierLayer.draw(graphics, bird);
                //一次性将图片绘制到屏幕上
                g.drawImage(buffimg,0,0,null);

            }
            else {
                String over="游戏结束";
                g.setColor(Color.red);
                g.setFont(new Font("微软雅黑",1,40+20));
                g.drawString(over,105+50+100,100+80+150);
               /* g.setColor(Color.red);
                g.setFont(new Font("微软雅黑",1,40+20));
                String so=LoginFrame.sr;
                g.drawString(so,105+50+100,100+80+150+30+50);*/
                String reset="Space Reset Game";
                g.setColor(Color.yellow);
                g.setFont(new Font("微软雅黑",1,40+20));
                g.drawString(reset,100+50+100,200+80+150+50);
                String resets="按下空格关闭程序";
                g.drawString(resets,100+50+100,300+80+150+50);
            }
            if (GameFrontGround.text==1){
            victory(g);
            bird.life=false;
            }
        }
    //监听器，按键
    public void add(KeyEvent e){
        switch (e.getKeyCode()){
            case KeyEvent.VK_UP:
                bird.fly(1);
                break;
            case KeyEvent.VK_SPACE:
                if(bird.life==false){
                    restart();
                }
                break;
            case KeyEvent.VK_LEFT:
                bird.fly(10);
                System.out.println("pppp");
                break;
        }
    }
    //监听器，抬健
    public void minu(KeyEvent e){
        switch (e.getKeyCode()){
            case KeyEvent.VK_UP :
                bird.fly(5);
                break;
            case KeyEvent.VK_LEFT:
                bird.fly(15);
                System.out.println("fff");
                break;
        }

    }
    /**
     * 游戏
     */
    public void restart(){
       gameBarrierLayer.restant();
       bird.restartDraw();

       System.exit(0);

    }
    public void victory(Graphics g){

        g.setColor(Color.yellow);
        g.setFont(new Font("微软雅黑",1,50));
       g.drawString("恭喜过关: "+LoginFrame.sr,105+50+100,100+80+150+30+50);

    }
}




























