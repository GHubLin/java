package com.brid.main;

import com.brid.app.LoginFrame;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * 障碍物物理层
 */
public class GameBarrierLayer {
    private GameTime gameTime;
    //private GameFrame gameFrame;
    private Bird bird;
    //定义数据
    private int txt;
    //存放障碍物
    private List<Barrier> barriers;

    private Random random = new Random();

    public long differ;
    //存储名字
/*    private String sr;

    public String getSr() {
        return sr;
    }

    public void setSr(String sr) {
        this.sr = sr;
    }*/



    public GameBarrierLayer() {
        //gameFrame=new GameFrame();

        barriers = new ArrayList<>();
        gameTime=new GameTime();
        bird=new Bird();
       /* Barrier barrier = new Barrier(10, 0, 200, 0);
        barriers.add(barrier);
        Barrier barrier1 = new Barrier(10, 0, 300, 2);
        barriers.add(barrier1);*/
    }

    //绘制障碍物
    public void draw(Graphics g, Bird animal) {
        logic(g);//开始获取池
        //根据barriers里面又多少来进行绘制
        for (int i = 0; i < barriers.size(); i++) {
            Barrier barrier = barriers.get(i);
            if (barrier.isVisible()){
                barrier.draw(g);
            }else {
                Barrier remove=barriers.remove(i);
                Barrierpool.setPool(remove);
                i--;
            }
        }
        //死亡判断
        collideBird(animal);
        DownDie(animal);
    }
    public void logic(Graphics g) {

        //刚开始的时候!!!!!!!!!!
        if (barriers.size() == 0) {
            ran();
            gameTime.begin();
          /*  Barrier top = new Barrier(600, 0, numberTop, 0);
            barriers.add(top);
            Barrier down = new Barrier(600, 500 - numberDown, numberDown, 2);
            barriers.add(down);*/
            insert(1000,0,numberTop+250,0);
            insert(1000,700-numberDown,numberDown+100,2);
        } else {
            //计时
            differ = gameTime.differ();
            g.setColor(Color.white);
            g.setFont(new Font("微软雅黑",1,20+10));
            g.drawString("存活了:"+(differ)+"秒",30,50+60);
            g.setColor(Color.black);
            g.setFont(new Font("微软雅黑",1,20+10));
//            System.out.println(LoginFrame.sr);
            g.drawString("玩家："+ LoginFrame.sr,30,60);
            txt=getTxt();
            if ((differ)<=(txt)){
                g.setColor(Color.red);
                g.setFont(new Font("微软雅黑",1,20+10));
                g.drawString("游玩最长记录:"+(txt),100+50+50+30,50+50+10);
            }else {
                /*GameBackGround ground=new GameBackGround();
                if (ground.Cloudcollider(bird)==true){
                    setTxt(String.valueOf(differ+1));
               }*/
                setTxt(String.valueOf(differ));
                g.drawString("最长时间:"+getTxt(),200,50);

            }
           /*else if (gameFrontGround.getText()==20){
                gameFrame.victory(g);
            }*/
            //判断后一个障碍物是否完全进入屏幕内
            Barrier last = barriers.get(barriers.size() - 1);
            if (last.isInFrame()) {
                ran();
                if (number<150){
                insert(1000,32+40,350+250,4);//num为设置的高度
                }else if (number>300){
                    insert(1000,125+400,200+250,6);
                }
                else {
                    insert(1000,0,numberTop+250,0);
                    insert(1000,700-numberDown,numberDown+100,2);
                }
            }
        }
    }
    File file=new File("D:\\game_bird.txt");
    /**
     * 用于得到文件中的数据
     */
    public int getTxt(){
        //得到一个输出字符流
        BufferedReader in = null;
        try {
            in = new BufferedReader(new FileReader(file));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        //读取一行字符
        int read= 0;
        try {
            read = Integer.parseInt(in.readLine());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //关闭
        try {
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return read;
    }
    /**
     * 用于储存数据
     */
    public  void setTxt(String str){
        //得到一个输入字符流
        FileWriter fileWriter= null;
        try {
            fileWriter = new FileWriter(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fileWriter.write(str);
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            fileWriter.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    /**
     * 用于从池中获取对象，并把参数封装，然后存入barriers数组中
     */
    public void insert(int x,int y,int num,int type){
        Barrier top=Barrierpool.getPool();
        top.setX(x);
        top.setY(y);
        top.setHeight(num);
        top.setType(type);
        top.setVisible(true);
        barriers.add(top);
    }
    //上方障碍物高度
    private int numberTop;
    //下方障碍物高度
    private int numberDown;
    //障碍物类型数目
    private int number;

    //产生两个100~500之间的随机高度===无物理
    public void ran() {
        numberTop = random.nextInt(400) + 10;
        numberDown = random.nextInt(400) + 10;
        number=random.nextInt(500);
        //如果管道重合，则重新随机
        if (numberTop + numberDown > 280) {
            ran();
        }
    }
    /**
     *判断障碍物和小鸟发生碰撞====需要两个对象，一个是本类，另一个是形参
     */
    public boolean collideBird(Bird animal){
        for (int i = 0; i < barriers.size(); i++) {
            Barrier barrier=barriers.get(i);
            //判断矩形是否相交
            if (barrier.getRect().intersects(animal.getRect())){
                //System.out.println("111");
                animal.life=true;
            }
        }
        return false;
    }
    /**
     * 超出边界死亡
     * @param animal
     * @return
     */
    public boolean DownDie(Bird animal) {
        //System.out.println("11"+animal.getdie());
        if (animal.getY()>1000) {
            //System.out.println("aaaaa");
            animal.life = false;
        }
        return false;
    }
    /**
     * 用于清空障碍物的池子
     */
    public void restant(){
        barriers.clear();
    }


}
