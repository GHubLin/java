package com.brid.main;

import com.brid.util.GameUtil;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Cloud {
    //声明引用变量

    private BufferedImage img;
    private int speed;
    private int x,y;
    public Rectangle rect;
    public Cloud(){
        rect=new Rectangle();
        //this(GameUtil.loadBufferedImage("img/Cloud0.png"),0,10,10);
    }
    public Cloud(BufferedImage img, int speed, int x, int y) {
        //由于碰撞矩形要参数，所以需要一个传参数
        //int w=GameUtil.loadBufferedImage("img/Cloud0.png").getWidth();
      /// int h=GameUtil.loadBufferedImage("img/Cloud0.png").getHeight();
      // System.out.println(rect.getWidth());
        //rect=new Rectangle(w,h);
        this.img = img;
        this.speed = speed+5;
        this.x = x;
        this.y = y;
//      this.rect=rect;

    }
    public void draw(Graphics g){
        //画出图片
        g.drawImage(img,x,y,null);
        //给予云速度
        x-=speed;
        /*g.drawRect(x,y, rect.width, rect.height);
        rect.x=this.x;
        rect.y=this.y;*/
        rect(g);
        if (x<-50){
            visible=false;
        }
    }
    /**
     * 用于判断云彩是否飞出屏幕外
     */
    public boolean isOutFrame(){
        if (x<10){
            return true;
        }
        return false;
    }
    /**
     * 碰撞矩形
     * @return
     */
    public void rect(Graphics g){
        int x1=this.x;
        int y1=this.y;
        // System.out.println(x+100);
        int w1=GameUtil.loadBufferedImage("img/peng0.png").getWidth();
        int h1=GameUtil.loadBufferedImage("img/peng0.png").getHeight();
        g.setColor(Color.blue);
        //g.drawRect(x1,y1,w1,h1);
        setRecyangle(x1,y1,w1,h1);
    }
    /**
     * 碰撞矩形参数
     * @return
     */
    public void setRecyangle(int x,int y,int width,int height){
        rect.x=x;
        rect.y=y;
        rect.width=width;
        rect.height=height;
    }

    public boolean isInFrame(){
        return 600-x>0;
    }
    public BufferedImage getImg() {
        return img;
    }

    public void setImg(BufferedImage img) {
        this.img = img;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Rectangle getRect() {
        return rect;
    }

    public void setRect(Rectangle rect) {
        this.rect = rect;
    }

    private boolean visible;

    public boolean isVisible() {
        return visible;
    }

    public void setVisible(boolean visible) {
        this.visible = visible;
    }
}
