package com.brid.main;

import com.brid.app.LoginFrame;
import com.brid.util.GameUtil;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//游戏的前景类
public class GameFrontGround {
    static int  text;
    public String sr;
    //云彩的个数
    private static final int CLOUND_COUNT=1;

    private static final int DECORATION_COUNT=3;
    //存放云彩的容器----容器的作用是存储数据，防止数据随着方法调用的结束而消失。因此当需要对数据进行增删时，需要建立容器。
    private List<Cloud> clouds;

    private List<Decoration> decorations;

//    public  List<Integer> intRect=new ArrayList<>();
    //云彩的飞翔速度
    private static final int CLOUNG_SPEED=1;
    //使用到图片资源
    private BufferedImage[] img;

    private BufferedImage[] decorationImg;
    //产生随机数
    private Random random;


    //初始化数据
    public GameFrontGround() {
        clouds=new ArrayList<>();
        decorations=new ArrayList<>();
        img=new BufferedImage[CLOUND_COUNT];
        decorationImg=new BufferedImage[DECORATION_COUNT];
        //容器中添加云彩的图片
        for (int i = 0; i <CLOUND_COUNT; i++) {
            img[i]= GameUtil.loadBufferedImage("img/peng"+i+".png");
        }
        for (int i = 0; i < DECORATION_COUNT; i++) {
            decorationImg[i]=GameUtil.loadBufferedImage("img/decoration"+i+".png");
          //  System.out.println("d8as8d8asd"+"img/bird2_"+i+".png");
        }
        random=new Random();
    }
    //绘制云彩
    public void draw(Graphics g,Bird bird){
       /* //对Cloud类中的构造器传入参数
        Cloud cloud=new Cloud(img[1],CLOUNG_SPEED,300,300);
        //添加到容器中
        clouds.add(cloud);
        //将它绘制出来
        clouds.get(i).draw(g);*/
        logic(g);
        g.setColor(Color.yellow);
        g.setFont(new Font("微软雅黑",1,25));
        g.drawString("随机分"+getText(),30,60+110);

        g.setFont(new Font("微软雅黑",1,25));
        g.drawString("设置的难度：0~"+LoginFrame.ra,700,60);
        logicOfDecoration(g);
        for (int i = 0; i < clouds.size(); i++) {
            Cloud cloud  = clouds.get(i);
            if (cloud.isVisible()){
                cloud.draw(g);
            }else {
                Cloud remove=clouds.remove(i);
                Cloudpool.setPool(remove);
                i--;
            }
        }
        for (int i = 0; i <decorations.size(); i++) {
            //绘制出来
            decorations.get(i).draw(g);
        }
        Cloudcollider(bird);

    }


    /**
     * 用于从池中获取对象，并把参数封装，然后存入数组中
     */
    public void insert(BufferedImage[] img,int speed,int x1,int y1){
        Cloud top=Cloudpool.getPool();
        top.setX(x1);
        top.setY(y1);
        top.setSpeed(speed);

        for (int i = 0; i < CLOUND_COUNT; i++) {
            top.setImg(img[i]);
        }

        top.setVisible(true);
        clouds.add(top);
        //System.out.println("111"+clouds.get(1));
        //System.out.println("88888"+clouds);
    }

    public static long getText() {
        return text;
    }

    public void setText(int text) {
        this.text = text;
    }

    //矩形碰撞交叉
    public boolean Cloudcollider(Bird bird){
        for (int i = 0; i <clouds.size(); i++) {
            Cloud cloud = clouds.get(i);
            if (cloud.getRect().intersects(bird.getRect())){
                sr=LoginFrame.ra;
                text=random.nextInt(Integer.parseInt(sr))+(1);
                System.out.println(""+getText());
                clouds.remove(0);
//              bird.life=true;
                return true;
            }
// System.out.println("12355252525252525"+clouds.get(i));
        }
        //System.out.println(cloud.x+"  " + " "+ cloud.y);
        //System.out.println(bird.x+" "+"  "+ bird.y );
        //判断矩形是否相交
        /*if (cloud.getRect().intersects(bird.getRect())){
            System.out.println("222");
            bird.life=true;
        }*/
        return false;
    }

    /**
     * 用于云彩的个数控制
     */
    private void logic(Graphics g) {
        if (clouds.size() == 0) {
            for (int i = 0; i < CLOUND_COUNT; i++) {
                img[i] = GameUtil.loadBufferedImage("img/peng0.png");
                insert(img, 10, 400+400, 100);
                insert(img, 10, 400+400, 400);
                insert(img, 10, 400+400, 700);

            }

        } else {
            Cloud last = clouds.get(clouds.size() - 1);
            if (last.isInFrame()) {
                for (int i = 0; i < CLOUND_COUNT; i++) {
                    img[i] = GameUtil.loadBufferedImage("img/peng" + i + ".png");
                    insert(img, 3, 500 + 400, random.nextInt(400)+300);
                }
                //BufferedImage img = GameUtil.loadBufferedImage("img/Cloud0.png");
            }
            /*if ((int)(Math.random()*500)<10){//公式：Math.random()*(n-m)+m，生成大于等于m小于n的随机数；
                Cloud cloud=new Cloud(img[random.nextInt(CLOUND_COUNT)],CLOUNG_SPEED,500,random.nextInt(350));
                clouds.add(cloud);
                System.out.println(clouds.size()==0);
        }*/

        /*for (int i = 0; i <clouds.size(); i++) {
            Cloud cloud=clouds.get(i);
            if (cloud.isOutFrame()){
                //清除云朵
                clouds.remove(i);
                //将索取地址的光标往后移动一位
                i--;
                //System.out.println("云朵被清除"+cloud);
            }
        }*/
        }
    }
    private void logicOfDecoration(Graphics g){
        if ((int)(Math.random()*500)<10){
            Decoration decoration=new Decoration(decorationImg[random.nextInt(DECORATION_COUNT)],CLOUNG_SPEED,1000,random.nextInt(450)+100);
            decorations.add(decoration);
        }
        for (int i = 0; i < decorations.size(); i++) {
            Decoration decoration=decorations.get(i);
            if (decoration.isOutFrame()){
                decorations.remove(i);
                i--;
            }
        }
    }
}
