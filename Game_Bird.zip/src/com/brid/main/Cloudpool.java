package com.brid.main;

import java.util.ArrayList;
import java.util.List;

public class Cloudpool {
    //用于管理池中所有对象的容器
    private static List<Cloud> pool=new ArrayList<>();
    //池中初始的对象个数
    public static final int initCount=16;
    //对象池中最大个数====限制
    public static final int maxCount=20;
    static {
        //初始化池中的对象
        for (int i = 0; i < initCount; i++) {
            pool.add(new Cloud());
        }
    }
    /**
     * 从池中获取"一个" 对象 这样需要就调用，不浪费内存
     */
    public static Cloud getPool(){
        int size=pool.size();
        //池中有对象才可以拿
        if (size>0){
            //返回移除对象群
            // System.out.println("拿走对象");
            return pool.remove(size-1);
        }else {
            //若池中没有对象
            System.out.println("创建新的对象");
            return new Cloud();
        }
    }
    /**
     * 将对象归还容器中
     */
    public static void setPool(Cloud cloud){
        if (pool.size()<maxCount){
            pool.add(cloud);
            //System.out.println("归还对象");
        }
    }
}
