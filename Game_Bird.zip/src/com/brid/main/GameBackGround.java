package com.brid.main;

import com.brid.util.Constant;
import com.brid.util.GameUtil;

import java.awt.*;
import java.awt.image.BufferedImage;

import static com.brid.util.Constant.*;

public class GameBackGround {
    //private List<Floor> floors=new ArrayList<>();
    //需要的图片声明
    private BufferedImage bkimg;
    //构造器初始化图片
    public GameBackGround(){
        bkimg= GameUtil.loadBufferedImage(Constant.BK_IMG_OATH);
        /*for (int i = 0; i < 20; i++) {
            floors.add(new Floor(i*10,i*450));
        }*/
    }
    //绘制图片
    public void draw(Graphics g){

        //填充背景色
        g.setColor(BK_COLOR);
        g.fillRect(0,0,FRAM_WIDTH,FRAM_HEIGHT);
        //画笔颜色重新设置
        g.setColor(Color.black);
        //得到图片的高度和宽度
        int height=bkimg.getHeight();
        int width=bkimg.getWidth();
        //需要的图片张数,循环
        int count=Constant.FRAM_WIDTH/width+1;
        for (int i = 0; i < count; i++) {
            g.drawImage(bkimg,width*i,Constant.FRAM_HEIGHT-height,null);
        }
       /* g.setColor(Color.red);
        g.drawImage(GameUtil.loadBufferedImage("img/button_ok.png"),200,420,null);
*/
    }

   /* public List<Floor> getFloors() {
        return floors;
    }*/
}
