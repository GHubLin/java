package com.brid.util;

import java.awt.*;

//资源常量存放
public class Constant {
    public static  final int FRAM_WIDTH=1000;
    public static  final int FRAM_HEIGHT=800;
    public static  final String FRAM_TITLE="飞翔的小猫";
    //窗口初始化的位置
    public static  final int FRAM_X=200;
    public static  final int FRAM_Y=20;
    //背景图片路径
    public static final String BK_IMG_OATH= "img/land.jpg";
    //背景颜色
    public static final Color BK_COLOR=new Color(0x4B4CF);
    //动物的图片
    public static final String[] ANIMAL_IMA=
            {"img/car_normal.png","img/car_up.png","img/car_down.png","img/bird_normal.png"};
    //障碍物图片资源
    public static final String[] BARRIER_IMG_PATH=
            {"img/barrier1.png","img/barrier_up1.png","img/barrier_down1.png"};
}
